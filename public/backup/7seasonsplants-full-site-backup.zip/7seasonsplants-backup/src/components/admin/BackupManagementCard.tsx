import React, { useState, useEffect } from 'react';
import {
  Download,
  Database,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  FileArchive,
  Layers,
  Sparkles,
  Terminal,
} from 'lucide-react';

interface BackupManifest {
  appName?: string;
  backupDate?: string;
  totalFiles?: number;
  zipArchive?: {
    filename: string;
    sizeFormatted: string;
    downloadUrl: string;
  };
  tarArchive?: {
    filename: string;
    sizeFormatted: string;
    downloadUrl: string;
  };
  databaseCollections?: Record<string, number>;
}

export const BackupManagementCard: React.FC = () => {
  const [manifest, setManifest] = useState<BackupManifest | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRegenerating, setIsRegenerating] = useState<boolean>(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const fetchBackupInfo = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/backup/info');
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setManifest(data);
        }
      }
    } catch (err) {
      console.warn('Could not fetch backup info:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBackupInfo();
  }, []);

  const handleRegenerateBackup = async () => {
    try {
      setIsRegenerating(true);
      setStatusMsg(null);
      const res = await fetch('/api/backup/generate', { method: 'POST' });
      const data = await res.json();
      if (res.ok && data.success) {
        setStatusMsg({ type: 'success', text: 'Fresh backup generated successfully!' });
        fetchBackupInfo();
      } else {
        setStatusMsg({ type: 'error', text: data.error || 'Failed to generate backup' });
      }
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message || 'Error triggering backup generation' });
    } finally {
      setIsRegenerating(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-2xs max-w-3xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-gray-100">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/40 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-black text-emerald-950">
              Site & Database Backup
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Download the entire codebase, assets, configuration, and live Firestore database dump.
            </p>
          </div>
        </div>

        <button
          onClick={handleRegenerateBackup}
          disabled={isRegenerating}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold transition-colors cursor-pointer disabled:opacity-50 shrink-0 self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRegenerating ? 'animate-spin' : ''}`} />
          <span>{isRegenerating ? 'Generating Backup...' : 'Generate Fresh Backup'}</span>
        </button>
      </div>

      {statusMsg && (
        <div
          className={`p-3.5 rounded-2xl text-xs flex items-center gap-2.5 ${
            statusMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          {statusMsg.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* Backup Archive Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Main ZIP Download */}
        <div className="bg-emerald-50/60 rounded-2xl p-5 border border-emerald-100 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <FileArchive className="w-5 h-5 text-emerald-700" />
              <span className="text-xs font-black uppercase tracking-wider text-emerald-900">
                Full Site Archive (.ZIP)
              </span>
            </div>
            <p className="text-xs text-emerald-800/80 leading-relaxed">
              Complete standalone package: React 19 source code, Express backend, public assets, configs, and all exported database files.
            </p>
            <div className="flex items-center gap-3 pt-1 text-[11px] font-semibold text-emerald-950">
              <span className="bg-white/80 px-2.5 py-0.5 rounded-full border border-emerald-200/60">
                Size: {manifest?.zipArchive?.sizeFormatted || '~1.44 MB'}
              </span>
              <span className="bg-white/80 px-2.5 py-0.5 rounded-full border border-emerald-200/60">
                Files: {manifest?.totalFiles || 111}
              </span>
            </div>
          </div>

          <a
            href="/api/backup/download"
            download="7seasonsplants-full-site-backup.zip"
            className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-xs transition-colors cursor-pointer text-center"
          >
            <Download className="w-4 h-4" />
            <span>Download ZIP Backup</span>
          </a>
        </div>

        {/* Database JSON Dump Download */}
        <div className="bg-amber-50/60 rounded-2xl p-5 border border-amber-100 flex flex-col justify-between space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-amber-700" />
              <span className="text-xs font-black uppercase tracking-wider text-amber-900">
                Database Dump (.JSON)
              </span>
            </div>
            <p className="text-xs text-amber-800/80 leading-relaxed">
              Exported Firestore records: Combos, products, categories, orders, customers, coupons, banners, and store settings.
            </p>
            <div className="flex items-center gap-2 pt-1 flex-wrap text-[10px] font-semibold text-amber-900">
              <span className="bg-white/80 px-2 py-0.5 rounded-full border border-amber-200/60">
                Format: JSON
              </span>
              <span className="bg-white/80 px-2 py-0.5 rounded-full border border-amber-200/60">
                Firestore & Seed Data
              </span>
            </div>
          </div>

          <div className="flex gap-2">
            <a
              href="/api/backup/database-json"
              download="7seasonsplants-firestore-dump.json"
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-700 hover:bg-amber-800 text-white rounded-xl font-bold text-xs shadow-xs transition-colors cursor-pointer text-center"
            >
              <Download className="w-4 h-4" />
              <span>Download JSON</span>
            </a>
            <a
              href="/api/backup/download-tar"
              download="7seasonsplants-full-site-backup.tar.gz"
              title="Download TAR.GZ archive for Linux/macOS"
              className="inline-flex items-center justify-center px-3.5 py-2.5 bg-white hover:bg-amber-100/60 text-amber-800 border border-amber-200 rounded-xl font-bold text-xs transition-colors cursor-pointer"
            >
              <span>.tar.gz</span>
            </a>
          </div>
        </div>
      </div>

      {/* Database Collections Breakdown */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-emerald-700" />
          <h4 className="text-xs font-black uppercase tracking-wider text-gray-700">
            Backed Up Database Collections
          </h4>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
          {[
            { name: 'Products', count: manifest?.databaseCollections?.products ?? 4 },
            { name: 'Plant Combos', count: manifest?.databaseCollections?.combos ?? 4 },
            { name: 'Categories', count: manifest?.databaseCollections?.categories ?? 6 },
            { name: 'Orders', count: manifest?.databaseCollections?.orders ?? 13 },
            { name: 'Users', count: manifest?.databaseCollections?.users ?? 7 },
            { name: 'Coupons', count: manifest?.databaseCollections?.coupons ?? 4 },
            { name: 'Daily Deals', count: manifest?.databaseCollections?.dailyDeals ?? 2 },
            { name: 'Hero Banners', count: manifest?.databaseCollections?.banners ?? 3 },
          ].map((col) => (
            <div
              key={col.name}
              className="p-2.5 rounded-xl bg-gray-50 border border-gray-100 flex items-center justify-between"
            >
              <span className="text-gray-600 font-medium">{col.name}</span>
              <span className="font-bold text-emerald-700 bg-white px-2 py-0.5 rounded-md border border-gray-200/60 text-[11px]">
                {col.count}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Restore Cheat Sheet */}
      <div className="p-4 rounded-2xl bg-gray-900 text-gray-100 space-y-2 text-xs font-mono">
        <div className="flex items-center gap-2 text-emerald-400 font-bold">
          <Terminal className="w-4 h-4" />
          <span>How to run locally from this backup:</span>
        </div>
        <p className="text-gray-400 text-[11px] font-sans">
          Extract the archive, install dependencies, and launch the dev server:
        </p>
        <pre className="text-emerald-300 text-[11px] bg-black/40 p-2.5 rounded-lg overflow-x-auto">
{`unzip 7seasonsplants-full-site-backup.zip
cd 7seasonsplants-backup
npm install
npm run dev`}
        </pre>
      </div>
    </div>
  );
};
